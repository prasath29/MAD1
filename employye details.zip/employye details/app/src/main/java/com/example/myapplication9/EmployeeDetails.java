package com.example.myapplication9;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.database.sqlite.SQLiteStatement;
import android.os.Build;
public class EmployeeDetails extends SQLiteOpenHelper {
    public EmployeeDetails(Context context, String name, SQLiteDatabase.CursorFactory factory,int
            version){
        super(context, name, factory,version);
    }
    public void queryData(String sql){
        SQLiteDatabase database = getWritableDatabase();
        database.execSQL(sql);
    }
    public void insertData(String empno ,String empname ,String empsal , String empaddr ){
        SQLiteDatabase database = getWritableDatabase();
        String sql = "INSERT INTO Recruitment Values(NULL, ?,?,?,?)";
        SQLiteStatement statement = database.compileStatement(sql);
        statement.clearBindings();
        statement.bindString(1,empno);
        statement.bindString(2,empname);
        statement.bindString(3,empsal);
        statement.bindString(4,empaddr);
        statement.executeInsert();
    }
    public Cursor getData(String sql){
        SQLiteDatabase database = getReadableDatabase();
        return database.rawQuery(sql,null);
    }
    @Override
    public void onCreate(SQLiteDatabase db) {
    }
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
    }
}

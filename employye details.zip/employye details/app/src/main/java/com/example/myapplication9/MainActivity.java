package com.example.myapplication9;

import androidx.appcompat.app.AppCompatActivity;
import android.app.AlertDialog;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import java.sql.*;
public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    EditText editEmpno, editEmpName, editEmpsalary, editAddress;
    Button btnInsert, btnUpdate, btnDelete, btnView, btnViewAll;
    String empno,empname,empsal,empaddr;
    //Create database and table in MySQL
    //CREATE DATABASE EmployeeDetails;
    //USE EmployeeDetails;
    //CREATE TABLE Employee(Empno varchar(10),Empname varchar(25), Empsalary varchar(10), Address varchar(50));

    private static final String url = "jdbc:mysql://192.168.29.145:3306/EmployeeDetails";
    private static final String user = "myuser";
    private static final String pass = "myuser";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        editEmpno = findViewById(R.id.editEmpno);
        editEmpName = findViewById(R.id.editEmpname);
        editEmpsalary = findViewById(R.id.editEmpsalary);
        editAddress = findViewById(R.id.editAddress);
        btnInsert = findViewById(R.id.btnInsert);
        btnUpdate = findViewById(R.id.btnUpdate);
        btnDelete = findViewById(R.id.btnDelete);
        btnView = findViewById(R.id.btnView);
        btnViewAll = findViewById(R.id.btnViewAll);
        btnInsert.setOnClickListener(this);
        btnUpdate.setOnClickListener(this);
        btnDelete.setOnClickListener(this);
        btnView.setOnClickListener(this);
        btnViewAll.setOnClickListener(this);
    }
    public void onClick(android.view.View view){
        if(view==btnInsert)
            new Insert().execute();
        if(view==btnUpdate)
            new Update().execute();
        if(view==btnDelete)
            new Delete().execute();
        if(view==btnView)
            new View().execute();
        if(view==btnViewAll)
            new ViewAll().execute();
    }
    class Insert extends AsyncTask<Void, Void, Void> {
        String records = "", error = "";
        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            empno = "" + editEmpno.getText().toString().trim();
            empname = "" + editEmpName.getText().toString().trim();
            empsal = "" + editEmpsalary.getText().toString().trim();
            empaddr = "" + editAddress.getText().toString().trim();
        }
        @Override
        protected Void doInBackground(Void... voids) {
            try {
                Class.forName("com.mysql.jdbc.Driver").newInstance();
                Connection conn = DriverManager.getConnection(url, user,pass);
                Statement stmt = conn.createStatement();
                stmt.executeUpdate("INSERT INTO Employee(Empno,Empname,Empsalary,Address) VALUES ('" + empno + "','" + empname +
                                "','" + empsal + "','" + empaddr + "');");
                records = "Success, Records Added...";
            }catch(Exception e){
                error = e.toString();
            }
            return null;
        }
        @Override
        protected void onPostExecute(Void aVoid) {
            if(error != "")
                showMessage ("Error", error);
            else
                Toast.makeText(getApplicationContext(), records, Toast.LENGTH_LONG).show();
            //clearText ();
            super.onPostExecute(aVoid);
        }
    }
    class Update extends AsyncTask<Void, Void, Void> {
        String records = "", error = "";
        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            empno = "" + editEmpno.getText().toString().trim();
            empname = "" + editEmpName.getText().toString().trim();
            empsal = "" + editEmpsalary.getText().toString().trim();
            empaddr = "" + editAddress.getText().toString().trim();
        }
        @Override
        protected Void doInBackground(Void... voids) {
            try {
                Class.forName("com.mysql.jdbc.Driver").newInstance();
                Connection conn = DriverManager.getConnection(url, user,pass);
                Statement stmt = conn.createStatement();
                stmt.executeUpdate("UPDATE Employee SET Empname='" + empname +
                        "',Empsalary='" + empsal +
                        "',Address='" + empaddr + "' WHERE Empno='" + empno + "'");
                records = "Success, Record Updated";
            }catch(Exception e){
                error = e.toString();
            }
            return null;
        }
        @Override
        protected void onPostExecute(Void aVoid) {
            if(error != "")
                showMessage ("Error", error);
            else
                Toast.makeText(getApplicationContext(), records, Toast.LENGTH_LONG).show();
            //clearText ();
            super.onPostExecute(aVoid);
        }
    }
    class Delete extends AsyncTask<Void, Void, Void> {
        String records = "", error = "";
        protected void onPreExecute() {
            super.onPreExecute();
            empno = "" + editEmpno.getText().toString().trim();
        }
        @Override
        protected Void doInBackground(Void... voids) {
            try {
                Class.forName("com.mysql.jdbc.Driver").newInstance();
                Connection conn = DriverManager.getConnection(url, user,pass);
                Statement stmt = conn.createStatement();
                stmt.executeUpdate("DELETE FROM Employee WHERE Empno='" + empno + "'");
                records = "Success, Record Deleted...";
            }catch(Exception e) {
                error = e.toString();
            }
            return null;
        }
        @Override
        protected void onPostExecute(Void aVoid) {
            if(error != "")
                showMessage ("Error", error);
            else
                Toast.makeText(getApplicationContext(), records, Toast.LENGTH_LONG).show();
            //clearText ();
            super.onPostExecute(aVoid);
        }
    }
    class View extends AsyncTask<Void, Void, Void> {
        String records = "", error = "";
        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            empno = "" + editEmpno.getText().toString().trim();
        }
        @Override
        protected Void doInBackground(Void... voids) {
            try {
                Class.forName("com.mysql.jdbc.Driver").newInstance();
                Connection conn = DriverManager.getConnection(url, user,pass);
                Statement stmt = conn.createStatement();
                ResultSet rs = stmt.executeQuery("SELECT * FROM Employee WHERE Empno='" +
                        empno + "'");
                while(rs.next())
                    records += "Employee Detail\nEmpno= " + rs.getString(1) + "\nEmpname= " +
                            rs.getString(2) +
                            "\nEmpSalary= " + rs.getString(3) + "\nAddress= " + rs.getString(4) + "\n";
            }catch(Exception e){
                error = e.toString();
            }
            return null;
        }
        @Override
        protected void onPostExecute(Void aVoid) {
            if(error != "")
                showMessage ("Error", error);
            else
                showMessage ("Employee Details", records);
            //clearText ();
            super.onPostExecute(aVoid);
        }
    }
    class ViewAll extends AsyncTask<Void, Void, Void> {
        String records = "", error = "";
        int count=0;
        @Override
        protected Void doInBackground(Void... voids) {
            try {
                Class.forName("com.mysql.jdbc.Driver").newInstance();
                Connection conn = DriverManager.getConnection(url, user, pass);
                Statement stmt = conn.createStatement();
                ResultSet rs = stmt.executeQuery("SELECT * FROM Employee");
                while (rs.next())
                    records += ++count +". \nEmpno= " + rs.getString(1) + "\nEmpname= " +
                            rs.getString(2) +
                            "\nEmpSalary= " + rs.getString(3) + "\nAddress= " + rs.getString(4) + "\n";
            }
            catch(Exception e)
            {
                error = e.toString();
            }
            return null;
        }
        @Override
        protected void onPostExecute(Void aVoid) {
            if(error != "")
                showMessage ("Error", error);
            else
                showMessage ("Employee Details", records);
            //clearText ();
            super.onPostExecute(aVoid);
        }
    }
    public void showMessage (String title, String message)
    {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setCancelable(true);
        builder.setTitle(title);
        builder.setMessage(message);
        builder.show();
    }
    public void clearText ()
    {
        editEmpno.setText("");
        editEmpName.setText("");
        editEmpsalary.setText("");
        editAddress.setText("");
        editEmpno.requestFocus();
    }
}

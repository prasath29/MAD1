package com.example.myapplication7;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.database.sqlite.SQLiteDatabase;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;
import java.io.ByteArrayOutputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;
public class MainActivity extends AppCompatActivity
{
    EditText editFName,editLName,editDOB, editPhoneNo, editGender, editAddress, editEMail,
            editQualification, editBranch, editPMark, editLanguages;
    ImageView imagePhoto;
    Button btnUploadPhoto, btnSave, btnCancel;
    SQLiteDatabase db;
    public static EmployeeDB employeeDB;
    final int PICKFILE_RESULT_CODE = 1;
    @Override
    public void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        editFName=(EditText)findViewById(R.id.editFName);
        editLName=(EditText)findViewById(R.id.editLName);
        editDOB=(EditText)findViewById(R.id.editDOB);
        editPhoneNo=(EditText)findViewById(R.id.editPhoneNo);
        editGender=(EditText)findViewById(R.id.editGender);
        editAddress=(EditText)findViewById(R.id.editAddress);
        editEMail=(EditText)findViewById(R.id.editEMail);
        editQualification=(EditText)findViewById(R.id.editQualification);
        editBranch=(EditText)findViewById(R.id.editBranch);
        editPMark=(EditText)findViewById(R.id.editPMark);
        editLanguages=(EditText)findViewById(R.id.editLanguages);
        imagePhoto=(ImageView)findViewById(R.id.imagePhoto);
        btnUploadPhoto=(Button)findViewById(R.id.btnUploadPhoto);
        btnSave=(Button)findViewById(R.id.btnSave);
        btnCancel=(Button)findViewById(R.id.btnCancel);
        imagePhoto.setImageResource(0);
        ActivityCompat.requestPermissions(this,new
                String[]{Manifest.permission.READ_EXTERNAL_STORAGE},23);
        employeeDB = new EmployeeDB(this, "RecruitmentDB",null,1);
        employeeDB.queryData("CREATE TABLE IF NOT EXISTS Recruitment(FName VARCHAR,LName VARCHAR,DOB VARCHAR, " +
                "PhoneNo VARCHAR, Gender VARCHAR, Address VARCHAR, EMail VARCHAR, Qualification VARCHAR, " + "Branch VARCHAR, Mark VARCHAR, Languages VARCHAR, Photo BLOG);");
        btnUploadPhoto.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view){
                ActivityCompat.requestPermissions(MainActivity.this,
                        new String[]{Manifest.permission.READ_EXTERNAL_STORAGE},
                        PICKFILE_RESULT_CODE);
            }
        });
        btnSave.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view){
                try{

                    employeeDB.insertData(editFName.getText().toString().trim(),editLName.getText().toString().trim()
                            ,
                            editDOB.getText().toString().trim(), editPhoneNo.getText().toString().trim(),
                            editGender.getText().toString().trim(),editAddress.getText().toString().trim(),
                            editEMail.getText().toString().trim(), editQualification.getText().toString().trim(),
                            editBranch.getText().toString().trim(), editPMark.getText().toString().trim(),
                            editLanguages.getText().toString().trim(), imageViewToByte(imagePhoto));
                }
                catch(Exception e){
                    e.printStackTrace();
                }
                Toast.makeText(getApplicationContext(),
                        "Sucess, Data Added to Database", Toast.LENGTH_SHORT).show();
            }
        });
        btnCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view){
                clearText();
            }
        });
    }
    private byte[] imageViewToByte(ImageView image ) {
        Bitmap bitmap = ((BitmapDrawable)image.getDrawable()).getBitmap();
        ByteArrayOutputStream stream = new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.PNG,100,stream);
        byte[] byteArray = stream.toByteArray();
        return byteArray;
    }
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permission,
                                           @NonNull int[] grantResults) {
        if (requestCode == PICKFILE_RESULT_CODE) {
            if (grantResults.length > 0 && grantResults[0] ==
                    PackageManager.PERMISSION_GRANTED){
                Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
                intent.setType("*/*");
                startActivityForResult(intent, PICKFILE_RESULT_CODE);
            }
            else {
                Toast.makeText(getApplicationContext(),
                        "You don't have permission to access file location",
                        Toast.LENGTH_SHORT).show();
            }
            return;
        }
        super.onRequestPermissionsResult(requestCode,permission,grantResults);
    }
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data){
        if(requestCode == PICKFILE_RESULT_CODE && resultCode == RESULT_OK && data !=
                null) {
            Uri uri = data.getData();
            try {
                InputStream inputStream = getContentResolver().openInputStream(uri);
                Bitmap bitmap = BitmapFactory.decodeStream(inputStream);
                imagePhoto.setImageBitmap(bitmap);
            } catch(FileNotFoundException e){
                e.printStackTrace();
            }
        }
        super.onActivityResult(requestCode,resultCode,data);
    }
    public void clearText()
    {
        editFName.setText("");
        editLName.setText("");
        editDOB.setText("");
        editPhoneNo.setText("");
        editGender.setText("");
        editAddress.setText("");
        editEMail.setText("");
        editQualification.setText("");
        editBranch.setText("");
        editPMark.setText("");
        editLanguages.setText("");
        imagePhoto.setImageBitmap(null);
        editFName.requestFocus();
    }
}

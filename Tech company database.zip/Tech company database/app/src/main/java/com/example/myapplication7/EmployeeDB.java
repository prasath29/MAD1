package com.example.myapplication7;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.database.sqlite.SQLiteStatement;
import android.os.Build;
public class EmployeeDB extends SQLiteOpenHelper {
    public EmployeeDB(Context context, String name, SQLiteDatabase.CursorFactory factory,int
            version){
        super(context, name, factory,version);
    }
    public void queryData(String sql){
        SQLiteDatabase database = getWritableDatabase();
        database.execSQL(sql);
    }
    public void insertData(String FName ,String LName ,String DOB , String PhoneNo , String
            Gender ,
                           String Address,String EMail , String Qualification ,String Branch , String Mark ,
                           String Languages, byte[] Photo ){
        SQLiteDatabase database = getWritableDatabase();
        String sql = "INSERT INTO Recruitment Values(NULL, ?,?,?,?,?,?,?,?,?,?,?,?)";
        SQLiteStatement statement = database.compileStatement(sql);
        statement.clearBindings();
        statement.bindString(1,FName);
        statement.bindString(2,LName);
        statement.bindString(3,DOB);
        statement.bindString(4,PhoneNo);
        statement.bindString(5,Gender);
        statement.bindString(6,Address);
        statement.bindString(7,EMail);
        statement.bindString(8,Qualification);
        statement.bindString(9,Branch);
        statement.bindString(10,Mark);
        statement.bindString(11,Languages);
        statement.bindBlob(12,Photo);
        statement.executeInsert();
    }
    public Cursor getData(String sql){
        SQLiteDatabase database = getReadableDatabase();
        return database.rawQuery(sql,null);
    }
    @Override
    public void onCreate(SQLiteDatabase db) {
    }
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
    }
}

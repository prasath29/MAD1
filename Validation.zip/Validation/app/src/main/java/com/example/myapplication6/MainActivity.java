package com.example.myapplication6;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
public class MainActivity extends AppCompatActivity {
    EditText editUName, editIDNo;
    Button btnValidate;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        editUName=(EditText)findViewById(R.id.editUName);
        editIDNo=(EditText)findViewById(R.id.editIDNo);
        btnValidate=(Button)findViewById(R.id.btnValidate);
        btnValidate.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {
                if(editUName.getText().toString().matches("[a-zA-Z ]+") &&
                        (editIDNo.getText().toString().matches("[\\d]+")&&
                                editIDNo.getText().toString().trim().length()==4))
                    Toast.makeText(getApplicationContext(), "Validation Successful",
                            Toast.LENGTH_LONG).show();
                if(editUName.getText().toString().trim().length()==0 ||
                        editIDNo.getText().toString().trim().length()==0)
                    Toast.makeText(getApplicationContext(),"Please enter allvalues",
                            Toast.LENGTH_LONG).show();
                if(!(editUName.getText().toString().trim().matches("[a-zA-Z ]+")))
                    Toast.makeText(getApplicationContext(),"Please enter only alphabets",
                            Toast.LENGTH_LONG).show();
                if(!(editIDNo.getText().toString().trim().matches("[\\d ]+")) ||
                        editIDNo.getText().toString().trim().length()!=4)
                    Toast.makeText(getApplicationContext(),"Please enter only four digit number",
                            Toast.LENGTH_LONG).show();
            }
        });
    }
}
